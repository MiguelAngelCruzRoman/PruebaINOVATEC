# Kivyx : An experiment of Kivy widgets

## Dependencies

```
pip install git+https://github.com/gottadiveintopython/asynckivy.git@master#egg=asynckivy
```

## LICENSE

Everything in this repository can be used under MIT license except the stuff inside `assets_just_for_tests_and_examples` directory. Those are not mine.

## Potential API Break in the future

A list of breaking changes that might be applied when the major version is changed.

- rename `KXMagnet2` to `KXMagnet`, and remove the original.
